package com.example.prietomyapplication

import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val redInput = findViewById<EditText>(R.id.editRedText)
        val greenInput = findViewById<EditText>(R.id.editGreenNum)
        val blueInput = findViewById<EditText>(R.id.editBlueNum)
        val button = findViewById<Button>(R.id.button)
        val colorBox = findViewById<TextView>(R.id.colorBox)

        button.setOnClickListener {
            // Get values (default to 0 if empty)
            val r = redInput.text.toString().toIntOrNull() ?: 0
            val g = greenInput.text.toString().toIntOrNull() ?: 0
            val b = blueInput.text.toString().toIntOrNull() ?: 0

            // Clamp values to [0,255]
            val red = r.coerceIn(0, 255)
            val green = g.coerceIn(0, 255)
            val blue = b.coerceIn(0, 255)

            // Create color
            val color = Color.rgb(red, green, blue)

            // Update box background and text
            colorBox.setBackgroundColor(color)
            colorBox.text = "Created color from RGB inputs"
        }
    }
}
